﻿using consoleTask_10;
using System;
using System.Windows.Forms;

namespace guiTask_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                Task10 t = new Task10();
                label1.Text = t.FInfo;
                label2.Text = t.GetDirectoryInfo();
            }
            catch (Exception exc)
            {
                label1.Text = exc.Message;
                label2.Visible = false;
            }
        }
    }
}